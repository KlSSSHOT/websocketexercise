const { time } = require('console')
const ws =require('nodejs-websocket')
const TYPE_ENTER = 1
const TYPE_LEAVE = 2
const TYPE_MSG = 3

/**
  分析:
    消息不应该是简单的字符串 
    这个消息应该是一个对象
    type: 消息的类型 0:表示进入聊天室的消息 1:表示用户离开聊天室的消息 2:正常的聊天消息
    msg: 消息的内容
    time: 聊天的具体时间
 */
let count =0
//记录当前连接上来的用户数量

const server = ws.createServer(conn =>{
    console.log("新的连接");
    count++
		conn.userName=`用户${count}`
		//1.告诉所有用户,有人加入聊天室
		//接受到了浏览器的数据
		broadcast({
      type:TYPE_ENTER,
      msg:`${conn.userName}进入了聊天室`,
      time:new Date().toLocaleTimeString()
    })


    conn.on("text",data=>{
        //2.当我们接收到某个用户的信息时,告诉所有用户,发送的消息内容是什么
				broadcast({
          type:TYPE_MSG,
          msg:`用户${count}`+':'+data,
          time:new Date().toLocaleTimeString()
        })
    })
    //关闭连接时触发
    conn.on("close",data=>{
        console.log("关闭连接");
        count--
				//3.有人离开后,告诉所有人有人离开了了聊天室
				broadcast({
          type:TYPE_LEAVE,
          msg:`${conn.userName}离开了聊天室`,
          time:new Date().toLocaleTimeString()
        })
    })
    conn.on("error",data=>{
        console.log("发生异常");
    })
})

//广播,给所有用户发送信息
function broadcast(msg) {
	//server.connections为一个数组,里面涵盖了连接上服务器的所有人
	//foreach可以遍历数组
	server.connections.forEach(item=>{
		item.send(JSON.stringify(msg))
	})
}
server.listen(3000,()=>{
    console.log("监听3000端口");
})


