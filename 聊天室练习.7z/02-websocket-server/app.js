//1.导入nodejs-websocket包
const ws =require('nodejs-websocket')

const PORT=3000
//2.创建服务
 const server=ws.createServer(connect=>{
    console.log("有用户链接");
    //每当结构从用户传递过来的数据,这个text事件会被触发
    connect.on("text",data=>{
        console.log("接收到用户数据",data);
        //给用户一个响应数据
        //对用户发送过来的数据进行处理,例:把小写改为大写,并拼接内容
        connect.send(data.toUpperCase()+"!!")
        // data.toUpperCase()将小写变成大写
    })
    //只要websocket连接断开,close事件就会触发
    connect.on("close",()=>{

            console.log("连接断开了!");
    })

    connect.on("error",()=>{

        console.log("用户连接异常!");
})
})

server.listen(PORT,()=>{
    console.log("websocket服务启动成功!,正在监听"+PORT+"端口");
})