var app = require('express')();
var server = require('http').Server(app);
var io = require('socket.io')(server);

//启动服务器
server.listen(3000,()=>{
    console.log("服务器已启动");
});

app.get('/', function (req, res) {
  res.sendfile(__dirname + '/index.html');
});

io.on('connection', function (socket) {
    socket.on("hehe",data=>{
        console.log(data);
    })
});